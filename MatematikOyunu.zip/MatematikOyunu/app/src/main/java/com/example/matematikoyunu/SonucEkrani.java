package com.example.matematikoyunu;

import android.os.Bundle;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class SonucEkrani extends AppCompatActivity {
    EditText dogru;
    EditText yanlis;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sonuc_ekrani);

        dogru = (EditText)findViewById(R.id.editText);
        yanlis = (EditText)findViewById(R.id.editText2);


        Bundle extras = getIntent().getExtras();
        Integer dogruSayisi = extras.getInt("dogru_sayisi");
        Integer yanlisSayisi = extras.getInt("yanlis_sayisi");

        dogru.setText(String.valueOf(dogruSayisi));
        yanlis.setText(String.valueOf(yanlisSayisi));


    }

}
