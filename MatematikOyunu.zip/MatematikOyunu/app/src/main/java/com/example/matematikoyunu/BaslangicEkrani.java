package com.example.matematikoyunu;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BaslangicEkrani extends Activity {

    Button toplama;
    Button cikarma;
    Button carpma;
    Button bolme;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.baslangic);

        toplama = (Button)findViewById(R.id.button6);
        cikarma = (Button)findViewById(R.id.button7);
        carpma = (Button)findViewById(R.id.button8);
        bolme = (Button)findViewById(R.id.button9);

        toplama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent MainActivity = new Intent(BaslangicEkrani.this, ToplamaEkrani.class);
                startActivity(MainActivity);
            }
        });

        cikarma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent MainActivity = new Intent(BaslangicEkrani.this, CikarmaEkrani.class);
                startActivity(MainActivity);
            }
        });

        carpma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent MainActivity = new Intent(BaslangicEkrani.this, CarpmaEkrani.class);
                startActivity(MainActivity);
            }
        });

        bolme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent MainActivity = new Intent(BaslangicEkrani.this, BolmeEkrani.class);
                startActivity(MainActivity);
            }
        });

    }


}
